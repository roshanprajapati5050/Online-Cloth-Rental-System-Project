<?php

$host = 'localhost';
$user = 'root';
$password = '';
$db = 'cloth_rental';

$link = mysqli_connect($host, $user, $password, $db);


?>