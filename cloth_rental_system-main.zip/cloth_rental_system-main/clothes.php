<?php
session_start();
include 'connect.php';
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cloth Rental</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/user.css">
    <link rel="stylesheet" href="assets/w3css/w3.css">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700,400italic,700italic" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">

    <!-- Navigation -->
    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation" style="color: black">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                    </button>
                <a class="navbar-brand page-scroll" href="index.php">
                   Cloth Rental </a>
            </div>
           <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
                <ul style="color:black;" class="nav navbar-nav">
                    <li>
                        <a href="index.php">Home</a>
                    </li>
                    <li>
                        <a href="clothes.php">All Clothes</a>
                    </li>
                    <li>
                        <a href="mybookings.php">booking</a>
                    </li>
                    <?php
                    if(isset($_SESSION['email'])){ ?>
                        <li>
                        <a href=""></span><?php echo $_SESSION['email'] ?></a>
                        </li>
                        <li>
                        <a href="logout.php">Logout <span class="glyphicon glyphicon-log-out"></span></a>
                        </li>
                        <?php } else { ?>
                            <li>
                                <a href="./login.php"></span>Login</a>
                            </li>
                    <?php } ?>
                    <ul class="nav navbar-nav">
                <ul class="dropdown-menu">
            </ul>
            </li>
          </ul>
                </ul>
            </div>
        </div>
    </nav>
    <br>
    <?php
    
    if (isset($_GET['category'])) {
        $category_id = $_GET['category'];
        $sql = "select * from clothes where category_id = '{$category_id}'";
    }else{
        $sql = "select * from clothes";
    }

    $run = mysqli_query($link, $sql);
    $count = mysqli_num_rows($run);
    ?>

    <div id="sec2" style="color: #777;background-color:white;text-align:center;padding:50px 80px;text-align: justify;">
        <h3 style="text-align:center;">Available Clothes</h3>
<br>
<div class="category-container">
<?php
$query ="SELECT * FROM category";
$result = $link->query($query);
if($result->num_rows> 0){
    $options= mysqli_fetch_all($result, MYSQLI_ASSOC);
}?>
<a href="./clothes.php"><div class="category" style="color: red;">All Clothes</div></a>
<?php
foreach ($options as $option) {
?>
    <a href="./clothes.php?category=<?php echo $option['category_id'];?>">
    <!-- <a href="./clothes.php?category=<?php echo $option['category_id']; ?>"  class="btn"><?php echo $option['category_name']; ?></a> -->

        <div class="category" style="background-color: #6cf079;">
            <?php echo $option['category_name']; ?>
        </div>
    </a>
    <?php
}
    ?>
    </div>
    <br>
        <section class="menu-content">
            <?php
            while ($row = mysqli_fetch_assoc($run)) {
                if(isset($_SESSION['email'])){ ?>
                <a href="./booking.php?id=<?php echo $row['cloth_id']; ?>">
                    <?php
                } else { ?>
                    <a style="cursor:pointer" onclick="alert('Please Login First')">
                <?php 
                }
                ?>
                <div class="sub-menu">
                <img class="card-img-top" src="./uploaded_img/<?php echo $row['image']; ?>" alt="Card image cap">
                <h5><b> <?php echo $row['name']; ?> </b></h5>
                <h6> Rent Price(per day): Rs <?php echo $row['price']; ?></h6>
                </div> 
                </a>                                                     
            <?php } ?>           
        </section>
    </div>

    <footer class="site-footer">
        <div class="container">
            <hr>
            <div class="row">
                <div class="col-sm-6">
                    <h5>© 2025 Cloth Rental</h5>
                </div>
                
            </div>
        </div>
    </footer>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <!-- Plugin JavaScript -->
    <script src="assets/js/jquery.easing.min.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="assets/js/theme.js"></script>
</body>

</html>